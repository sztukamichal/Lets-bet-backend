package com.dtd.letsbet.repositories;

import com.dtd.letsbet.model.Account;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface AccountRepository extends CrudRepository<Account, Long> {
    void deleteAll();
}
