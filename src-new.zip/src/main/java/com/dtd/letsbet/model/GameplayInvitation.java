package com.dtd.letsbet.model;

public class GameplayInvitation extends Invitation {

	Gameplay gameplay;
	private String message;

}