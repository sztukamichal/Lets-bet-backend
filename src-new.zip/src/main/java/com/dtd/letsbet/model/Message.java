package com.dtd.letsbet.model;

public class Message {

	Conversation conversation;
	private int ID;
	private String message;

	public void sendMessage() {
		// TODO - implement Message.sendMessage
		throw new UnsupportedOperationException();
	}

}