package com.dtd.letsbet.model;

import java.util.*;

public class SpecialBet extends Bet {

	GameplayTemplate gameplayTemplate;
	List<SpecialBetPrediction> specialBetPredictions;
	private List<String> options;
	private String correctOption;
	private int pointsToGain;

	public void markCorrectOption() {
		// TODO - implement SpecialBet.markCorrectOption
		throw new UnsupportedOperationException();
	}

	public void addOption() {
		// TODO - implement SpecialBet.addOption
		throw new UnsupportedOperationException();
	}

	public void removeOption() {
		// TODO - implement SpecialBet.removeOption
		throw new UnsupportedOperationException();
	}

}