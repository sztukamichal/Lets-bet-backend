package com.dtd.letsbet.model;

import java.util.Date;

public class Notification {

	Player player;
	NotificationType notificationType;
	private int ID;
	private String message;
	private boolean isRead;
	private Date createdDate;
	private String value;

}