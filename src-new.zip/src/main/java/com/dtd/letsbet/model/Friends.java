package com.dtd.letsbet.model;

import java.util.Date;

public class Friends {

	Player player;
	Player friends;
	private int ID;
	private Date creationDate;

}