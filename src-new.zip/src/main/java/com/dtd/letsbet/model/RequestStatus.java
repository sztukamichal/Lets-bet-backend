package com.dtd.letsbet.model;

import java.util.*;

public class RequestStatus {

	List<RequestForGameplay> requestForGameplay;
	private int ID;
	private String name;

}