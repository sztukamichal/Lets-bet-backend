package com.dtd.letsbet.model;

public class Administrator extends Account {

	public void deleteAccount() {
		// TODO - implement Administrator.deleteAccount
		throw new UnsupportedOperationException();
	}

	public void changePlayerStatus() {
		// TODO - implement Administrator.changePlayerStatus
		throw new UnsupportedOperationException();
	}

	public void createModerator() {
		// TODO - implement Administrator.createModerator
		throw new UnsupportedOperationException();
	}

}