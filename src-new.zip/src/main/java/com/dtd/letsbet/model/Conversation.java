package com.dtd.letsbet.model;

import java.util.*;

public class Conversation {

	List<Account> account;
	List<Message> messages;
	private int ID;
	private String name;

}