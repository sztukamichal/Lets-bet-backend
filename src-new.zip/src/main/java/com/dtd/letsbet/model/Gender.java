package com.dtd.letsbet.model;

import java.util.*;

public class Gender {

	List<Person> person;
	private int ID;
	private String name;

}