package com.dtd.letsbet.model;

import java.util.*;

public class Shoutbox {

	Gameplay gameplay;
	List<Post> posts;
	private int ID;

}