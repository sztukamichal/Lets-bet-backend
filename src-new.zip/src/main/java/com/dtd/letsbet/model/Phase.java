package com.dtd.letsbet.model;

import java.util.*;

public class Phase {

	GameplayTemplate gameplayTemplate;
	List<Bet> bet;
	private int ID;
	private String name;
	private String description;
	private int extraPoints;

	public void changeInformation() {
		// TODO - implement Phase.changeInformation
		throw new UnsupportedOperationException();
	}

}