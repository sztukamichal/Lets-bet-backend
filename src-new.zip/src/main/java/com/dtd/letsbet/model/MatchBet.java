package com.dtd.letsbet.model;

import com.dtd.letsbet.model.ExternalData.Match;

import java.util.*;

public class MatchBet extends Bet {

	Match match;
	List<MatchBetPrediction> matchBetPredictions;

}