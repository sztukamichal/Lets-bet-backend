package com.dtd.letsbet.model;

import java.util.*;

public class GameplaysType {

	List<GameplayConfiguration> gameplayConfiguration;
	private int ID;
	private String name;

}