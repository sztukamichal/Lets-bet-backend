package com.dtd.letsbet.model;

public class TeamMatch {

	Match match;
	Team team;
	private int ID;
	private boolean isHomeTeam;

}