package com.dtd.letsbet.model;

import java.util.Date;

public class RequestForGameplay {

	Player requester;
	RequestStatus requestStatus;
	Gameplay gameplay;
	private int ID;
	private String message;
	private Date createdDate;
	private Date resolvedDate;

}