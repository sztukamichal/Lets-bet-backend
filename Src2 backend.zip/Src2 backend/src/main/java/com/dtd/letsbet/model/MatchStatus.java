package com.dtd.letsbet.model;

import java.util.*;

public class MatchStatus {

	List<Match> match;
	private int ID;
	private String name;

}