package com.dtd.letsbet.model;

import javax.persistence.*;
import java.util.*;

@Entity
@Table(name = "footballer")
public class Footballer {

	//List<Team> teams;

	@Id
	@SequenceGenerator(name="seq-gen",sequenceName="bet_id_seq", initialValue=2, allocationSize=12)
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="seq-gen")
	private int ID;

	@Column(name = "externalId")
	private int externalId;

	@Column(name = "name")
	private int name;

	@Column(name = "position")
	private String position;

	private int jerseyNumber;
	private Date dateOfBirth;
	private String nationality;
	private Date contractUntil;
	private String marketValue;



}