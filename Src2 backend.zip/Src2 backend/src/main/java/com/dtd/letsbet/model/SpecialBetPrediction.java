package com.dtd.letsbet.model;

import java.util.Date;

public class SpecialBetPrediction {

	PredictionStatus predictionStatus;
	SpecialBet specialBet;
	Player player;
	private int ID;
	private String chosenOption;
	private Date updateDate;
	private int gainedPoints;

}