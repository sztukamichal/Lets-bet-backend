package com.dtd.letsbet.model;

import java.util.Date;

public class Administrator { //extends Account {


	//public Administrator(int accounttypeid, int playerstatusid, String login, Date createdDate, String email, String password, Date lastLoginDate, int lockout, Date lockoutdate, int points, int avatarid, String screenname, int tokens, Date moderatorcreateddate, String discriminator) {
//

	public void deleteAccount() {
		// TODO - implement Administrator.deleteAccount
		throw new UnsupportedOperationException();
	}

	public void changePlayerStatus() {
		// TODO - implement Administrator.changePlayerStatus
		throw new UnsupportedOperationException();
	}

	public void createModerator() {
		// TODO - implement Administrator.createModerator
		throw new UnsupportedOperationException();
	}

}