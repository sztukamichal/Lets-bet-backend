package com.dtd.letsbet.model;

import javax.persistence.*;
import java.util.*;

/**
 * Competition created by player (becomes a organizer) involving other player's as participants. Consists of set of phases. Defined by rules.
 */

//@Entity
///@Table(name="gameplay")
public class Gameplay {


	//@Id
	//@SequenceGenerator(name="seq-gen",sequenceName="bet_id_seq", initialValue=2, allocationSize=12)
	//@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="seq-gen")
	private int ID;

	//@Column(name = "name")
	private String name;

	//@Column(name = "description")
	private String description;

	Player organizer;
	List<GameplayInvitation> gameplayInvitations;
	List<RequestForGameplay> requestsForGameplay;
	List<ChangeConfigurationRequest> changeRequests;
	GameplayStatus gameplayStatus;
	List<Position> positions;
	Shoutbox shoutbox;
	GameplayConfiguration gameplayConfiguration;
	GameplayTemplate gameplayTemplate;


	private Date startDate;

	public void invitePlayer() {
		// TODO - implement Gameplay.invitePlayer
		throw new UnsupportedOperationException();
	}

	public void changeInformation() {
		// TODO - implement Gameplay.changeInformation
		throw new UnsupportedOperationException();
	}

	public void acceptRequest() {
		// TODO - implement Gameplay.acceptRequest
		throw new UnsupportedOperationException();
	}

	public void declineRequest() {
		// TODO - implement Gameplay.declineRequest
		throw new UnsupportedOperationException();
	}

}