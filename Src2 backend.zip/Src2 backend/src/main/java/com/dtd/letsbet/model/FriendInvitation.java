package com.dtd.letsbet.model;

public class FriendInvitation extends Invitation {
}