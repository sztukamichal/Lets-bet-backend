package com.dtd.letsbet.repositories;

import com.dtd.letsbet.model.Account;
import com.dtd.letsbet.model.Player;
import org.springframework.data.repository.CrudRepository;

public interface PlayerRepository extends CrudRepository<Player, Long> {

}
