package com.dtd.letsbet.repositories;

import com.dtd.letsbet.model.AccountType;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface AccountTypeRepository extends CrudRepository<AccountType, Long> {
    List<AccountType> findByName(String name);
}
