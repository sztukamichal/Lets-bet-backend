package com.dtd.letsbet.model;

import javax.persistence.*;
import java.util.List;


@Entity
@Table(name = "accounttype")
public class AccountType {



	@Id
	@SequenceGenerator(name="seq-gen",sequenceName="accounttype_id_seq", allocationSize=12)
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="seq-gen")
	private int ID;


	@Column(name = "name")
	private String name;

	@OneToMany(mappedBy="accounttype")
	private List<Account> account;

	protected AccountType() {
	}

	public AccountType(String name) {
	    this.name = name;
	}

	@Override
	public String toString() {
		return "AccountType{" +
				"ID=" + ID +
				", name='" + name + '\'' +
				'}';
	}




}