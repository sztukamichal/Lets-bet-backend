package com.dtd.letsbet.model;

public class PartialResult {

	Result finalResult;
	Result halfTimeResult;
	Result extraTimeResult;
	Result penaltyShootoutResult;
	private int ID;
	private int goalsHomeTeam;
	private int goalsAwayTeam;

}