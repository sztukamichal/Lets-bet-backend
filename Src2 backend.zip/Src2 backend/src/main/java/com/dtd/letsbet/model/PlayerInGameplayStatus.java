package com.dtd.letsbet.model;

import java.util.*;

public class PlayerInGameplayStatus {

	List<Position> position;
	private int ID;
	private String name;

}