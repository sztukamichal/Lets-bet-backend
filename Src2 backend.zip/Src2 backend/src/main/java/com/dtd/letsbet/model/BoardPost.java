package com.dtd.letsbet.model;

import java.util.Date;

public class BoardPost {

	Board board;
	Moderator author;
	private int ID;
	private String message;
	private Date createdDate;

}