package com.dtd.letsbet.model;

import javax.persistence.*;
import java.util.*;



@Entity
@Inheritance
@DiscriminatorColumn(name="discriminator")
@Table(name="account")
public class Account {


	//List<ChangeConfigurationRequest> declinedChangeConfigurationRequest;
	//List<ChangeConfigurationRequest> acceptedChangeConfigurationRequest;
	//List<Conversation> conversation;


	@Id
	@SequenceGenerator(name="seq-gen",sequenceName="account_id_seq", allocationSize=12)
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="seq-gen")
	private int ID;


	@ManyToOne
	@JoinColumn(name="accounttypeid")
	private AccountType accounttype;


	@ManyToOne
	@JoinColumn(name="playerstatusid")
	private PlayerStatus playerstatus;


	@Column(name = "login")
	private String login;

	@Column(name = "createddate")
	private Date createddate ;

	@Column(name = "email")
	private String email;

	@Column(name = "password")
	private String password;

	@Column(name = "lastlogindate")
	private Date lastlogindate;

	@Column(name = "lockout")
	private int lockout;

	@Column(name = "lockoutdate")
	private Date lockoutdate;

	//@Column(name = "discriminator")
	//private String discriminator;


	protected Account() {
	}

	/*public Account(int accounttypeid, int playerstatusid,String login, Date createddate , String email, String password,
				   Date lastlogindate , int lockout, Date lockoutdate, int points, int avatarid, String screenname,
				   int tokens, Date moderatorcreateddate, String discriminator  ) {
		this.accounttypeid  = accounttypeid ;
		this.playerstatusid  = playerstatusid ;
		this.login = login;
		this.createddate  = createddate ;
		this.email = email;
		this.password = password;
		this.lastlogindate  = lastlogindate ;
		this.lockout = lockout;
		this.lockoutdate  = lockoutdate ;
		this.discriminator = discriminator;
	}*/




	public void changePassword() {
		// TODO - implement Account.changePassword
		throw new UnsupportedOperationException();
	}




}