package com.dtd.letsbet.model;

public class Result {

	PartialResult finalResult;
	PartialResult halfTime;
	PartialResult extraTime;
	PartialResult penaltyShootout;
	MatchBetPrediction matchBetPrediction;
	Match match;
	private int ID;

}