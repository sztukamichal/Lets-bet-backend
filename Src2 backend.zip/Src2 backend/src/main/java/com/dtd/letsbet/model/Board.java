package com.dtd.letsbet.model;

import java.util.*;

public class Board {

	List<BoardPost> boardPosts;
	private int ID;

}