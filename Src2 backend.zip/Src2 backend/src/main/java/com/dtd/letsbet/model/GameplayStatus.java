package com.dtd.letsbet.model;

import java.util.*;

public class GameplayStatus {

	List<Gameplay> gameplay;
	private int ID;
	private String name;

}