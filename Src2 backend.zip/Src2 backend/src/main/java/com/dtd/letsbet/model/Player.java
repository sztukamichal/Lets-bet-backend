package com.dtd.letsbet.model;

import javax.persistence.*;
import java.util.*;

/**
 * Main user type of system, that can take part in gameplays.
 */

@Entity
@DiscriminatorValue("player")
public class Player extends Account {

	//List<Position> positions;
	//List<Friends> friends;
	//List<ChangeConfigurationRequest> createdChangeConfigurationRequest;
	//List<SpecialBetPrediction> specialBetPredictions;
	//List<MatchBetPrediction> matchBetPredictions;
	//List<Invitation> receivedInvitations;
	//List<Notification> notifications;
	//List<Post> posts;
	//List<Gameplay> createdGameplays;
	//List<Invitation> sentInvitation;
	//List<RequestForGameplay> requestsForGameplays;
	//PlayerStatus playerStatus;

	@Column(name = "points")
	private int points;

	@Column(name = "avatarid")
	private int avatarid;

	@Column(name = "screenname")
	private String screenname;

	@Column(name = "tokens")
	private int tokens;


	private Player() {
	}

	public Player(int accounttypeid, int playerstatusid, String login, Date createdDate, String email, String password, Date lastLoginDate, int lockout, Date lockoutdate, int points, int avatarid, String screenname, int tokens) {
	}

	public void changeAccountType() {
		// TODO - implement Player.changeAccountType
		throw new UnsupportedOperationException();
	}

	public void changeAvatar() {
		// TODO - implement Player.changeAvatar
		throw new UnsupportedOperationException();
	}

	public void changeScreenName() {
		// TODO - implement Player.changeScreenName
		throw new UnsupportedOperationException();
	}

	@Override
	public String toString() {
		return "Player{" + "avatar id " + avatarid +
				", points " + points  + '\'' +
				'}';
}


}