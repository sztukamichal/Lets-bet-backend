package com.dtd.letsbet.model;

import java.util.Date;

public class Post {

	Shoutbox shoutbox;
	Player author;
	private int ID;
	private String message;
	private Date createdDate;

}