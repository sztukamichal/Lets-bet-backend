package com.dtd.letsbet.model;

import javax.persistence.*;
import java.util.*;

@Entity
@Table(name = "match")
public class Match {

	//Competition competition;
	//List<MatchBet> matchBets;
	//Result result;
	//MatchStatus matchStatus;
	//List<TeamMatch> teamMatch;

	@Id
	@SequenceGenerator(name="seq-gen",sequenceName="match_id_seq", initialValue=2, allocationSize=12)
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="seq-gen")
	private int ID;

	@Column(name = "externalid")
	private int externalId;

	@Column(name = "Date")
	private Date date;

	@Column(name = "matchday")
	private int matchday;

	@Column(name = "hometeamname")
	private String homeTeamName;

	@Column(name = "externalhometeamid")
	private int externalHomeTeamId;

	@Column(name = "awayteamname")
	private String awayTeamName;

	@Column(name = "externalawayteamid")
	private int externalAwayTeamId;

}