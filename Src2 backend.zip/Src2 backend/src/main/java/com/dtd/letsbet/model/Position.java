package com.dtd.letsbet.model;

public class Position {

	PlayerInGameplayStatus playerInGameplayStatus;
	Gameplay gameplay;
	Player player;
	private int ID;
	private int rank;
	private int gainedPoints;

}