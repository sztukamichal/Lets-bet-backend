package com.dtd.letsbet.model;

import java.util.*;

public class GameplayTemplateStatus {

	List<GameplayTemplate> gameplayTemplate;
	private int ID;
	private String name;

}