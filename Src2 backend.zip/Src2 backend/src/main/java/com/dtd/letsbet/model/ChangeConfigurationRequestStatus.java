package com.dtd.letsbet.model;

import java.util.*;

public class ChangeConfigurationRequestStatus {

	List<ChangeConfigurationRequest> changeConfigurationRequest;
	private int ID;
	private String name;

}