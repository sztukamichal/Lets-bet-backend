package com.dtd.letsbet.model;

import java.util.*;

public class NotificationType {

	List<Notification> notification;
	private int ID;
	private String name;

}