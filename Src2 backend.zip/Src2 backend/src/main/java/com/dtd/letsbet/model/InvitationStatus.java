package com.dtd.letsbet.model;

import java.util.*;

public class InvitationStatus {

	List<Invitation> invitation;
	private int ID;
	private String name;

}