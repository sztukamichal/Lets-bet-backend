package com.dtd.letsbet.model;

import javax.persistence.*;
import java.util.*;

@Entity
@DiscriminatorValue("Moderator")
public class Moderator extends Account {

	//List<GameplayTemplate> createdGameplayTemplates;
	//List<BoardPost> boardPosts;

	@Column(name = "moderatorcreateddate")
	private Date moderatorcreateddate;



	public void createGameplayTemplate() {
		// TODO - implement Moderator.createGameplayTemplate
		throw new UnsupportedOperationException();
	}

	public void postMessageToBoard() {
		// TODO - implement Moderator.postMessageToBoard
		throw new UnsupportedOperationException();
	}

}