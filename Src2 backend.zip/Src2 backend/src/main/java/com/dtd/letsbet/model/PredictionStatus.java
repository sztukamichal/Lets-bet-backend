package com.dtd.letsbet.model;

import java.util.*;

public class PredictionStatus {

	List<SpecialBetPrediction> specialBetPrediction;
	List<MatchBetPrediction> matchBetPrediction;
	private int ID;
	private String name;

}