package com.dtd.letsbet.model;

import java.util.*;

public class LeagueTable {

	List<Standing> standings;
	Competition competition;
	private int ID;
	private String leagueCaption;
	private int matchDay;

}