package com.dtd.letsbet.model;

import javax.persistence.*;
import java.util.*;

@Entity
@Table(name="playerstatus")
public class PlayerStatus {

	//List<Player> player;

	@Id
	@SequenceGenerator(name="seq-gen",sequenceName="accounttype_id_seq", allocationSize=12)
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="seq-gen")
	private int ID;


	@Column(name = "name")
	private String name;

	@OneToMany(mappedBy="playerstatus")
	private List<Account> account;

}