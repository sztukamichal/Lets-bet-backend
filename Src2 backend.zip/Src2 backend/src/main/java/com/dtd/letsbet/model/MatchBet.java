package com.dtd.letsbet.model;

import java.util.*;

public class MatchBet extends Bet {

	Match match;
	List<MatchBetPrediction> matchBetPredictions;

}