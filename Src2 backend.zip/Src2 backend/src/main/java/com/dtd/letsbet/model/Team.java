package com.dtd.letsbet.model;

import javax.persistence.*;
import java.util.*;

@Entity
@Table(name="team")
public class Team {

	//List<Competition> competitions;
	//List<TeamMatch> teamMatch;
	//List<Standing> standings;
	//List<Footballer> footballers;

	@Id
	@SequenceGenerator(name="seq-gen",sequenceName="team_id_seq", initialValue=2, allocationSize=12)
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="seq-gen")
	private int ID;

	@Column(name = "name")
	private String name;

	@Column(name = "code")
	private String code;

	@Column(name = "shortname")
	private String shortName;

	@Column(name = "squadmarketvalue")
	private String squadMarketValue;

	@Column(name = "cresturl")
	private String crestUrl;

	@Column(name = "externalid")
	private int externalId;
}